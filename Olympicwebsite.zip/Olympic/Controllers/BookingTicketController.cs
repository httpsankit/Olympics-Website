﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using Olympic.Models;

namespace Olympic.Controllers
{
    public class BookingTicketController : Controller
    {
        OlympicsEntities db = new OlympicsEntities();
        public ActionResult Index(int id)
        {
            Sport sport = db.Sports.Where(z => z.Id == id).FirstOrDefault();
            var maxbookedseat = 0;
            if (db.Booked_tickets.Where(z=>z.Sports_id==id).Count() != 0)
            {
                 maxbookedseat = (from bl in db.Booked_tickets
                                              
                                               where bl.Sports_id == id && bl.Active == true
                                            orderby bl.Seat_number descending
                                            select bl.Seat_number).FirstOrDefault();
            }
            
            if (maxbookedseat < sport.Total_seats)
            {
                sport.Total_seats = sport.Total_seats - maxbookedseat;
            }
            else
            {
                ViewBag.isaloowtopay = "no";
                sport.Total_seats = sport.Total_seats - maxbookedseat;
            }
                return View(sport);
        }
        [HttpPost]
        public ActionResult Index(Sport sport)
        {
            var existingSport=db.Sports.Where(z => z.Id == sport.Id).Select(z=>new { z.Total_seats,z.Ticket_price}).FirstOrDefault();
           
            if (existingSport.Total_seats<sport.Total_seats)
            {
                return View(sport);
            }
            else
            {
                Session["seats"] = "";
                Session["Amount"] = existingSport.Ticket_price;
                Session["SportId"] = sport.Id;
                Session["noOfTkts"] = sport.Total_seats;
                return RedirectToAction("Index","Payment");
            }

           
        }

        }
}