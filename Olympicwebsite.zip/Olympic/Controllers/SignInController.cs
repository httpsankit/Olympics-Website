﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Olympic.Models;

namespace Olympic.Controllers
{
    public class SignInController : Controller
    {
        OlympicsEntities db = new OlympicsEntities();
        public ActionResult Index()
        {
            Session["authorize"] = "";
            return View();
        }
        [HttpPost]
        public ActionResult Index(string Emailid, string Password)
        {
            bool islogined = db.Admins.Where(z => z.Emailid == Emailid && z.Password == Password).Any();
            if (!islogined)
            {
                islogined = db.Users.Where(z => z.Emailid == Emailid && z.Password == Password).Any();
                if (islogined)
                {
                    Session["authorize"] = "User";
                    Session["UserEmail"] = Emailid;
                }
                else
                {
                    Session["authorize"] = "1";
                    return View();
                }
            }
            else
                Session["authorize"] = "Admin";
            
            return RedirectToAction("Index","Home");
        }
        public ActionResult SignOut()
        {
            Session["authorize"] = "";
            Session["UserEmail"] = "";
            return RedirectToAction("Index", "Home");
        }
    }
}