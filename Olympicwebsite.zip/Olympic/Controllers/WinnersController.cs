﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Olympic.Models;

namespace Olympic.Controllers
{
    public class WinnersController : Controller
    {
        OlympicsEntities db = new OlympicsEntities();
        public ActionResult Index()
        {
            return View(db.Medals.ToList());
        }
        public ActionResult AddWinner()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddWinner(Medal medal)
        {
            medal.Total = medal.Gold + medal.Silver + medal.Bronze;
            db.Medals.Add(medal);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult EditMedals(int id)
        {
            return View(db.Medals.Where(z=>z.Id==id).FirstOrDefault());
        }
        [HttpPost]
        public ActionResult EditMedals(Medal medal)
        {
            var Total = medal.Gold + medal.Silver + medal.Bronze;
            Medal medals = db.Medals.Where(z => z.Id == medal.Id).FirstOrDefault();
            medals.Total = Total;
            medals.Gold = medal.Gold;
            medals.Silver = medal.Silver;
            medals.Bronze = medal.Bronze;
            
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}