﻿using Olympic.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Olympic.Controllers
{
    public class SignUpController : Controller
    {
        OlympicsEntities db = new OlympicsEntities();
        public ActionResult Index()
        {
            Session["authorize"] = "";
            return View();
        }
        [HttpPost]
        public ActionResult Index(string Emailid, string Password, string Name, string Phonenumber)
        {
            Session["authorize"] = "";
            bool islogined = db.Users.Where(z => z.Emailid == Emailid).Any();
            if (!islogined)
            {
                Models.User user = new Models.User();
                user.Emailid = Emailid;
                user.Name = Name;
                user.Password = Password;
                user.Phone_number = Password;

                db.Users.Add(user);
                db.SaveChanges();

                return RedirectToAction("Index", "SignIn");
            }
            else
            {
                Session["authorize"] = "1";
                return View();
            }

            
        }
    }
}