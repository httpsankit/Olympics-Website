﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Olympic.Models;

namespace Olympic.Controllers
{
    public class SportsController : Controller
    {
        OlympicsEntities db = new OlympicsEntities();
        // GET: Sports
        public ActionResult Index()
        {
            return View(db.Sports.ToList());
        }
      
        public ActionResult NewSports()
        {
            return View();
        }
        [HttpPost]
        public ActionResult NewSports(Sport sport)
        {
            db.Sports.Add(sport);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}