﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using Olympic.Models;

namespace Olympic.Controllers
{
    public class PaymentController : Controller
    {
        OlympicsEntities db = new OlympicsEntities();
        public ActionResult Index()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Index(Booked_ticket booked_Ticket)
        {
            var seatnumbers = "";
            Random rd = new Random();
            var useremail = Session["UserEmail"].ToString();
            List<Booked_ticket> booked_Tickets = new List<Booked_ticket>();
            var sprtsid = int.Parse(Session["SportId"].ToString());
            int numberoftckts = int.Parse(Session["noOfTkts"].ToString());
            var sports = db.Sports.Where(z => z.Id == sprtsid).FirstOrDefault();
            var user = db.Users.Where(z => z.Emailid == useremail).FirstOrDefault();
            var maxbookedseat = 0;
            bool flag = false;
            if (db.Booked_tickets.Where(z => z.Sports_id == sprtsid).Count() != 0)
            {
                 maxbookedseat = (from bl in db.Booked_tickets
                                               orderby bl.Seat_number descending
                                               where bl.Sports_id == sprtsid && bl.Active == true
                                               select bl.Seat_number).FirstOrDefault();
            }
            
            if (maxbookedseat < sports.Total_seats)
            {
                if(numberoftckts==1)
                {
                    maxbookedseat++;
                    booked_Ticket.User_id = user.Id;
                    booked_Ticket.User_name = user.Name;
                    booked_Ticket.Sports_id = sprtsid;
                    booked_Ticket.Sports_name = sports.Game_name;
                    booked_Ticket.Seat_number = maxbookedseat;

                    seatnumbers = maxbookedseat.ToString();
                    booked_Ticket.Amount = decimal.Parse(Session["Amount"].ToString());
                    booked_Ticket.Active = true;
                    booked_Tickets.Add(booked_Ticket);
                }
                else
                {
                    for(int i=0;i<numberoftckts;i++)
                    {
                        flag = true;
                        booked_Ticket = new Booked_ticket();
                        maxbookedseat++;
                        booked_Ticket.User_id = user.Id;
                        booked_Ticket.User_name = user.Name;
                        booked_Ticket.Sports_id = sprtsid;
                        booked_Ticket.Sports_name = sports.Game_name;
                        booked_Ticket.Seat_number = maxbookedseat;

                        seatnumbers = seatnumbers+maxbookedseat.ToString()+ ",";
                        booked_Ticket.Amount = decimal.Parse(Session["Amount"].ToString());
                        booked_Ticket.Active = true;
                        booked_Tickets.Add(booked_Ticket);
                    }
                }
                db.Booked_tickets.AddRange(booked_Tickets);
                db.SaveChanges();
                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress("From Mail");
                    mail.To.Add(useremail);
                    mail.Subject = "Payment successfull";
                   
                        if (flag == true)
                    {
                        mail.Body = $"<h3>Dear {user.Name},<br/><br/>your payment is successful for {sports.Game_name}.<br/><br/>" +
                       $"Match date: {sports.Tournament_date} <strong>{seatnumbers.Remove(seatnumbers.Length - 1, 1) }</strong> " + $"- these are your seat number(s).<br/><br/>Enjoy your game.<br/><br/>regards,<br/>Olympic Team</h3>";
                    }
                    else
                    {
                        mail.Body = $"<h3>Dear {user.Name},<br/><br/>your payment is successful for {sports.Game_name}.<br/><br/>" +
                       $"Match date: {sports.Tournament_date} <strong>{seatnumbers}</strong> " + $"- is your seat number.<br/><br/>Enjoy your game.<br/><br/>regards,<br/>Olympic Team</h3>";
                    }
                     
                    mail.IsBodyHtml = true;

                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("From mail id", "Password");
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                }
            }
            return RedirectToAction("Index", "Sports");
        }
    }
}