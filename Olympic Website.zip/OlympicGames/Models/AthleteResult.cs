﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OlympicGames.Models
{
    public class AthleteResult
    {
        public decimal NumResult { get; set; }
        public string Result { get; set; }
        public string Name { get; set; }
    }
}