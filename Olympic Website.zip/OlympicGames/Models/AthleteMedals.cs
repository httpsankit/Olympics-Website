﻿namespace OlympicGames.Models
{
    public class AthleteMedals
    {
        public int AthleteId { get; set; }
        public string Name { get; set; }
        public int MedalsCount { get; set; }
    }
}