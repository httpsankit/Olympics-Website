﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OlympicGames.Models
{
    public enum MedalType
    {
        Gold = 1,
        Silver = 2,
        Bronze = 3
    }
}